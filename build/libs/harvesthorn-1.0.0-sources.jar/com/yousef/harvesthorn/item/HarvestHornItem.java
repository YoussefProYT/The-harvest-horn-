package com.yousef.harvesthorn.item;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2421;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class HarvestHornItem extends class_1792 {

    private final int size;
    private final boolean isHarver;

    public HarvestHornItem(class_1793 properties, int size) {
        this(properties, size, false);
    }

    public HarvestHornItem(class_1793 properties, int size, boolean isHarver) {
        super(properties);
        this.size = size;
        this.isHarver = isHarver;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        return method_7836(context.method_8045(), context.method_8036(), context.method_20287());
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        if (player == null) {
            return class_1269.field_5811;
        }

        class_1799 stack = player.method_5998(hand);
        if (world.method_8608()) {
            return class_1269.field_5812;
        }

        player.method_7357().method_62835(stack, 60);

        class_3218 serverWorld = (class_3218) world;
        class_3222 serverPlayer = (class_3222) player;
        class_2338 center = player.method_24515();

        processArea(serverWorld, serverPlayer, center, size);
        serverWorld.method_8396(null, center, class_3417.field_39024, class_3419.field_15248, 1.0F, 1.0F);
        spawnParticles(serverWorld, center, size);

        stack.method_71012(1, player, hand);
        return class_1269.field_5812;
    }

    private void processArea(class_3218 world, class_3222 player, class_2338 center, int size) {
        int start = -(size / 2);
        int end = start + size - 1;

        for (int x = start; x <= end; x++) {
            for (int z = start; z <= end; z++) {
                for (int y = -1; y <= 1; y++) {
                    processBlock(world, player, center.method_10069(x, y, z));
                }
            }
        }
    }

    private void processBlock(class_3218 world, class_3222 player, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        class_2248 block = state.method_26204();

        if (block instanceof class_2302 cropBlock) {
            if (cropBlock.method_9825(state)) {
                harvestCropAndReplant(world, player, pos, state, cropBlock);
            } else if (isHarver && cropBlock.method_9651(world, pos, state)) {
                cropBlock.method_9652(world, world.method_8409(), pos, state);
            }
            return;
        }

        if (block instanceof class_2421) {
            int age = state.method_11654(class_2421.field_11306);
            if (age >= class_2421.field_31199) {
                harvestNetherWart(world, player, pos, state);
            }
        }
    }

    private void harvestCropAndReplant(class_3218 world, class_3222 player,
                                       class_2338 pos, class_2680 state, class_2302 cropBlock) {
        List<class_1799> drops = class_2248.method_9609(state, world, pos,
                world.method_8321(pos), player, player.method_6047());

        for (class_1799 drop : drops) {
            giveOrDrop(player, world, pos, drop);
        }

        world.method_8652(pos, cropBlock.method_9828(0), class_2248.field_31036);
    }

    private void harvestNetherWart(class_3218 world, class_3222 player, class_2338 pos, class_2680 state) {
        List<class_1799> drops = class_2248.method_9609(state, world, pos,
                world.method_8321(pos), player, player.method_6047());

        for (class_1799 drop : drops) {
            giveOrDrop(player, world, pos, drop);
        }

        world.method_8652(pos, state.method_11657(class_2421.field_11306, 0), class_2248.field_31036);
    }

    private void giveOrDrop(class_3222 player, class_3218 world, class_2338 pos, class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }

        if (player.method_31548().method_7394(stack)) {
            return;
        }

        class_1542 itemEntity = new class_1542(world,
                pos.method_10263() + 0.5, pos.method_10264() + 0.6, pos.method_10260() + 0.5, stack);
        world.method_8649(itemEntity);
    }

    private void spawnParticles(class_3218 world, class_2338 center, int size) {
        double x = center.method_10263() + 0.5;
        double y = center.method_10264() + 0.5;
        double z = center.method_10260() + 0.5;

        world.method_8406(class_2398.field_11211,
                x, y, z,
                0.0D, 0.0D, 0.0D);
    }
}
