package com.yousef.harvesthorn.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.List;

public class ModItems {

    public static final class_1792 IRON_HORN = createItem("iron_horn", 100, 5, false, false);
    public static final class_1792 GOLDEN_HORN = createItem("golden_horn", 200, 10, false, false);
    public static final class_1792 DIAMOND_HORN = createItem("diamond_horn", 350, 15, false, false);
    public static final class_1792 NETHERITE_HORN = createItem("netherite_horn", 500, 20, true, false);
    public static final class_1792 THE_HARVER = createItem("the_harver", 2048, 20, true, true);

    private static class_1792 createItem(String name, int maxDamage, int size, boolean fireproof, boolean isHarver) {
        class_2960 id = class_2960.method_60655("harvesthorn", name);
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);

        class_1792.class_1793 properties = new class_1792.class_1793()
                .method_63686(key)
                .method_7895(maxDamage);

        if (fireproof) {
            properties.method_24359();
        }

        return register(id, new HarvestHornItem(properties, size, isHarver));
    }

    public static void register() {
        class_5321<class_1761> toolsTabKey = class_5321.method_29179(
                class_7924.field_44688,
                class_2960.method_60655("minecraft", "tools_and_utilities")
        );

        ItemGroupEvents.modifyEntriesEvent(toolsTabKey).register(entries -> {
            entries.prepend(IRON_HORN);
            entries.prepend(GOLDEN_HORN);
            entries.prepend(DIAMOND_HORN);
            entries.prepend(NETHERITE_HORN);
            entries.prepend(THE_HARVER);
        });
    }

    private static class_1792 register(class_2960 id, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, id, item);
    }

    public static List<class_1792> getItemsForCreativeTab() {
        List<class_1792> items = new ArrayList<>();
        items.add(IRON_HORN);
        items.add(GOLDEN_HORN);
        items.add(DIAMOND_HORN);
        items.add(NETHERITE_HORN);
        items.add(THE_HARVER);
        return items;
    }
}
