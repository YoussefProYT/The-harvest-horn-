package com.yousef.harvesthorn.datagen;

import com.yousef.harvesthorn.item.ModItems;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7924;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class HarvestHornDataGenerator implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(HarvestHornRecipeProvider::new);
    }

    public static class HarvestHornRecipeProvider extends FabricRecipeProvider {
        public HarvestHornRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
            super(output, registriesFuture);
        }

        @Override
        public String method_10321() {
            return "Harvest Horn recipes";
        }

        @Override
        protected class_2446 method_62766(class_7225.class_7874 registries, class_8790 exporter) {
            return new class_2446(registries, exporter) {
                @Override
                public void method_10419() {
                    createShapedRecipe(ModItems.IRON_HORN, "iron_horn", class_1802.field_8620);
                    createShapedRecipe(ModItems.GOLDEN_HORN, "golden_horn", class_1802.field_8695);
                    createShapedRecipe(ModItems.DIAMOND_HORN, "diamond_horn", class_1802.field_8477);
                    createShapedRecipe(ModItems.NETHERITE_HORN, "netherite_horn", class_1802.field_22020);
                    createTheHarverRecipe();
                }

                private void createShapedRecipe(class_1792 result, String recipeName, class_1792 material) {
                    class_2447 shapedRecipeBuilder = this.method_62746(class_7800.field_40638, result);
                    shapedRecipeBuilder.method_10439("MMM")
                            .method_10439("MGM")
                            .method_10439("MMM")
                            .method_10434('M', material)
                            .method_10434('G', class_1802.field_39057);

                    shapedRecipeBuilder.method_10429("has_goat_horn", this.method_10426(class_1802.field_39057));
                    shapedRecipeBuilder.method_17972(this.field_53721, recipeKey(recipeName));
                }

                private void createTheHarverRecipe() {
                    class_2447 shapedRecipeBuilder = this.method_62746(class_7800.field_40638, ModItems.THE_HARVER);
                    shapedRecipeBuilder.method_10439("NNN")
                            .method_10439("NGN")
                            .method_10439("NNN")
                            .method_10434('N', class_1802.field_22020)
                            .method_10434('G', class_1802.field_39057);

                    shapedRecipeBuilder.method_10429("has_goat_horn", this.method_10426(class_1802.field_39057));
                    shapedRecipeBuilder.method_17972(this.field_53721, recipeKey("the_harver"));
                }

                private class_5321<class_1860<?>> recipeKey(String recipeName) {
                    return class_5321.method_29179(class_7924.field_52178, class_2960.method_60655("harvesthorn", recipeName));
                }
            };
        }
    }
}
